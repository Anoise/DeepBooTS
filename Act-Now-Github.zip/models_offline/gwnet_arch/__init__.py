from .gwnet import Model

__all__ = ["GraphWaveNet"]
