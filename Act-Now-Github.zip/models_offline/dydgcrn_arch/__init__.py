from .dydgcrn import Model

__all__ = ["DGCRN"]
